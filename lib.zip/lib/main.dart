import 'package:work_exe/pertemuan14/exercise.dart';
// import 'package:work_exe/pertemuan14/pertemuan14screen.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Pertemuan14Exercise(),
    );
  }
}
